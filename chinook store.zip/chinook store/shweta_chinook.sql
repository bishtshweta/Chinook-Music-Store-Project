-- Objective questions:

use chinook;
  -- 1.Does any table have missing values or duplicates? If yes how would you handle it ?
  
  select * from album;
  select distinct*from album;  -- No duplicates
  
  select * from artist;
  select distinct* from artist; -- No duplicates
  
  select * from customer;
  select distinct * from customer; -- No duplicates
  
  select count(*) from customer;
   -- where fax is NULL; (count = 47)
   -- where state is NULL; (count = 29)
   -- where company is NULL; (count = 49)
   -- 47 fax, 29 state and 49 company values are null in the customer table
   
select * from employee; -- 1 reports_to value is null for employee_id = 1
select distinct * from employee; -- No Duplicates

select * from genre;
select distinct * from genre; -- no duplicates

select * from invoice;
select distinct * from invoice; -- no duplicates

select * from invoice_line; -- No duplicates
select distinct * from invoice_line;

select distinct * from media_type; -- no duplicates


select * from playlist ;
select distinct * from playlist; -- no duplicates

select * from playlist_track;
select distinct * from playlist_track; -- no duplicates

select * from track;
select distinct * from track; -- no duplicates

select * from playlist_track;
select distinct * from playlist_track; -- no duplicates

select count(*) from track
where 
composer is null; -- 978 composers have not been assigned any value/are null in the track table

/* 
no duplicate values in the whole dataset.
if null value found then would handle it with the COALESCE function.
*/

-- 2.	Find the top-selling tracks and top artist in the USA and identify their most famous genres.

select top_selling_track, top_artist, top_genre from 
(
SELECT t.name Top_selling_track, a.name Top_artist, g.name Top_genre, SUM(t.unit_price * il.quantity) FROM track t
LEFT JOIN invoice_line il on t.track_id = il.track_id
LEFT JOIN invoice i on i.invoice_id = il.invoice_id
LEFT JOIN album al on al.album_id = t.album_id
LEFT JOIN artist a on a.artist_id = al.artist_id
LEFT JOIN genre g on g.genre_id = t.genre_id
WHERE billing_country = "USA"
GROUP BY t.name, a.name, g.name
ORDER BY SUM(total) DESC
LIMIT 10
) Top_table;

-- For the top selling genre 

select Top_Genre from 
(
select g.name as Top_Genre
from track t
left join invoice_line il on il.track_id = t.track_id
left join invoice i on i.invoice_id = il.invoice_id
left join genre g on t.genre_id = g.genre_id
where i.billing_country = 'USA'
group by g.name
order by sum(il.quantity) desc
limit 10
) gen_table;

-- 3. What is the customer demographic breakdown (age, gender, location) of Chinook's customer base?

select count(distinct country) from customer; 
-- No. of Countries = 24

SELECT 
    country, COUNT(email) AS customer_count
FROM
    customer
GROUP BY country
ORDER BY customer_count DESC; 


-- no. of cx in the country :
-- USA:13
-- Canada:8 
-- Brazil:5
-- France:5
 -- Germany:4
 

/*
 cx base of Chinook music store is available across 24 countries. 
 USA has max no. of cx i.e. 13
 cx table table does not have age and gender columns to know about the customer breakdown.
*/

-- 4.	Calculate the total revenue and number of invoices for each country, state, and city:

select billing_country, billing_state, billing_city, count(*) as num_invoices, sum(total) as total_revenue
from invoice
group by billing_country, billing_state, billing_city
order by count(invoice_id) desc, sum(total) desc;

-- 5.	Find the top 5 customers by total revenue in each country

with cte as(
select customer_id, sum(total) as total_revenue
from invoice
group by customer_id),
cte2 as(
select concat(c.first_name,' ',c.last_name) as customer_name, c.country,
dense_rank() over(partition by c.country order by cte.total_revenue desc) as ranking
from customer c
right join cte on cte.customer_id = c.customer_id)
select customer_name, country,ranking from cte2 where ranking <=5
order by country;

-- 6.	Identify the top-selling track for each customer

WITH cte AS (
    SELECT 
        CONCAT(c.first_name, " ", c.last_name) AS customer_name,
        t.name AS track_name, 
        SUM(il.quantity) AS total_sales,
        ROW_NUMBER() OVER (
            PARTITION BY CONCAT(c.first_name, " ", c.last_name) 
            ORDER BY SUM(il.quantity) DESC
        ) AS r
    FROM customer c
    LEFT JOIN invoice i ON i.customer_id = c.customer_id
    LEFT JOIN invoice_line il ON il.invoice_id = i.invoice_id
    LEFT JOIN track t ON t.track_id = il.track_id
    GROUP BY CONCAT(c.first_name, " ", c.last_name), t.name
)
SELECT customer_name, track_name
FROM cte
WHERE r = 1;

-- 7.	Are there any patterns or trends in customer purchasing behavior
-- (e.g., frequency of purchases, preferred payment methods, average order value)?

select customer_id, avg(total) as avg_order_value, count(invoice_id)as num_of_orders
from invoice
group by customer_id
order by count(invoice_id);

SELECT 
    COUNT(invoice_id) AS daily_invoice_count,
    EXTRACT(YEAR_MONTH FROM invoice_date),
    AVG(total) AS monthly_avg_total,
    SUM(total) AS monthly_sum_total
FROM
    invoice
GROUP BY EXTRACT(YEAR_MONTH FROM invoice_date)
ORDER BY EXTRACT(YEAR_MONTH FROM invoice_date);

-- 8.	What is the customer churn rate?

WITH customer_number_in_1st_3months as 
(
SELECT COUNT(customer_id) totl from invoice
WHERE invoice_date BETWEEN '2017-01-01' AND '2017-03-31'
),

-- Let's assume that total number of cx at start = cx joined in first 3 months.

customer_number_in_last_2months as
(
SELECT COUNT(customer_id) later FROM invoice
WHERE invoice_date BETWEEN '2020-11-01' AND '2020-12-31' 
)

 -- Let's assume that churn rate is calculated on the basis of the no. of cx left in the last two months. 

SELECT ((SELECT totl FROM customer_number_in_1st_3months)-(SELECT later FROM customer_number_in_last_2months))
/(SELECT totl FROM customer_number_in_1st_3months) * 100 as churn_rate
;

/* 
The company's customer churn rate is 40.8163%, calculated based on the initial number of customers (49) over the first 3 months and the remaining customers in the last 2 months (29). 
Therefore, the number of customers lost is 49 - 29 = 20.
*/ 

-- 9.	Calculate the percentage of total sales contributed by each genre in the USA and identify the best-selling genres and artists.


WITH cte as
(
select sum(total) as total_USA_revenue from invoice
where billing_country = 'USA'
),
cte2 as
(
select g.name as genre_name, sum(t.unit_price * il.quantity) as total_genre_revenue
from genre g
right join track t on g.genre_id = t.genre_id
left join invoice_line il on il.track_id = t.track_id
left join invoice i on i.invoice_id = il.invoice_id
where billing_country = 'USA'
group by g.name 
order by total_genre_revenue DESC
),
cte_rank as
(
select genre_name, round(total_genre_revenue *100/(select total_USA_revenue from cte),2) perc_contri,
DENSE_RANK() over(order by round(total_genre_revenue *100/(select total_USA_revenue from cte),2) desc) ranking
from cte2
)
select cte_rank.genre_name, perc_contri, ranking from cte_rank;

/*
Rock	= 53.38
Alternative & Punk	= 12.37
Metal	= 11.80
R&B/Soul	= 5.04
Blues	= 3.43
Alternative	= 3.33
Latin	= 2.09
Pop	= 2.09
Hip Hop/Rap	= 1.90
Jazz	= 1.33
Easy Listening	= 1.24
Reggae	= 0.57
Electronica/Dance	= 0.48
Classical	= 0.38
Heavy Metal	= 0.29
TV Shows	= 0.19
Soundtrack	= 0.19
*/

-- 10.	Find customers who have purchased tracks from at least 3 different genres

SELECT name_of_customer, total FROM
(
SELECT CONCAT(first_name, ' ', last_name) name_of_customer, COUNT(DISTINCT g.name) total FROM customer c 
LEFT JOIN invoice i on i.customer_id = c.customer_id
LEFT JOIN invoice_line il on il.invoice_id = i.invoice_id
LEFT JOIN track t on t.track_id = il.track_id
LEFT JOIN genre g on g.genre_id = t.genre_id
GROUP BY 1 HAVING COUNT(DISTINCT g.name) >= 3
ORDER BY COUNT(DISTINCT g.name) DESC
) agg_table;

/* Leonie Köhler  .
*/

-- 11.	Rank genres based on their sales performance in the USA

WITH cte as
(
SELECT t.genre_id, g.name,  SUM(t.unit_price * il.quantity) sale_performance FROM track t
LEFT JOIN genre g on g.genre_id = t.genre_id
LEFT JOIN invoice_line il on il.track_id = t.track_id
LEFT JOIN invoice i on i.invoice_id = il.invoice_id
WHERE billing_country = 'USA'
GROUP BY 1, 2
)
SELECT name, sale_performance,
DENSE_RANK() OVER(ORDER BY sale_performance DESC) `rank` FROM cte
;
-- 12.	Identify customers who have not made a purchase in the last 3 months

SELECT 
    c.customer_id, 
    CONCAT(c.first_name, " ", c.last_name) AS customer_name
FROM 
    customer c
WHERE 
    c.customer_id NOT IN (
        SELECT DISTINCT i.customer_id
        FROM invoice i
        WHERE i.invoice_date >= DATE_SUB(NOW(), INTERVAL 3 MONTH)
    );


                                -- SUBJECTIVE

-- 1.	Recommend the three albums from the new record label that should be prioritised 
-- for advertising and promotion in the USA based on genre sales analysis.

select * from track order by album_id,genre_id; -- an album have songs with same/single genre
select genre_id from genre where name = 'Rock'; -- genre_id = 1 for Rock

with cte as(
select sum(i.total) as total_revenue, t.album_id
from invoice i left join invoice_line il on il.invoice_id = i.invoice_id
left join track t on t.track_id = il.track_id
where i.billing_country = 'USA' and t.genre_id = 1
group by t.album_id
order by total_revenue desc
)
select a.title, a.album_id, total_revenue  from album a
left join cte on cte.album_id = a.album_id
order by cte.total_revenue desc limit 3;

/*
The following albums should be given priority for advertising and promotion:
1. From The Muddy Banks Of The Wishkah [live] - 163
2. Are You Experienced? - 120
3. The Best Of Van Halen, Vol. I - 243
*/

-- 2.	Determine the top-selling genres in countries other than the USA and identify any commonalities or differences.

SELECT  g.genre_id, g.name, sum(t.unit_price * il.quantity) total_revenue_for_genre FROM track t
LEFT JOIN genre g on g.genre_id = t.genre_id
LEFT JOIN invoice_line il on il.track_id = t.track_id
LEFT JOIN invoice i on i.invoice_id = il.invoice_id
WHERE billing_country != 'USA'
GROUP BY 1,2
ORDER BY total_revenue_for_genre DESC;

/* 1. Rock genre on Top. 
2. METAL 2nd
3. ALTERNATIVE & Punk on 3rd.
*/

-- 3.	Customer Purchasing Behavior Analysis: How do the purchasing habits (frequency, basket size, spending amount) of long-term 
-- customers differ from those of new customers? What insights can these patterns provide about customer loyalty and retention strategies?

 WITH cte as
(
SELECT i.customer_id, MAX(invoice_date), MIN(invoice_date), 
abs(TIMESTAMPDIFF(MONTH, MAX(invoice_date), MIN(invoice_date))) as time_for_each_customer, 
SUM(total) sales, SUM(quantity) items, COUNT(invoice_date) frequency FROM invoice i
LEFT JOIN customer c on c.customer_id = i.customer_id
LEFT JOIN invoice_line il on il.invoice_id = i.invoice_id
GROUP BY 1
ORDER BY time_for_each_customer DESC
),
average_time as
(
SELECT AVG(time_for_each_customer) average FROM cte
),--  40.36 Months
categorization as
(
SELECT *,
CASE
WHEN time_for_each_customer > (SELECT average from average_time) THEN "Long-term Customer" ELSE "Short-term Customer" 
END category
FROM cte
)
SELECT category, SUM(sales) total_spending, SUM(items) basket_size, COUNT(frequency) frequency FROM categorization
GROUP BY 1 ;

/* 
Insights:
It is evident that long-term customers have higher spending, larger basket sizes, and greater purchasing frequency compared to short-term customers.

Recommendations:
The company should offer a wider variety of genres to long-term customers, as they contribute more to revenue. 
Customer loyalty is crucial for boosting company revenue, as long-term customers tend to make more purchases than short-term ones.
 */
 
 -- 4.	Product Affinity Analysis: Which music genres, artists, or albums are frequently purchased together by customers?
-- How can this information guide product recommendations and cross-selling initiatives?

select * from invoice_line;

SELECT 
    il.invoice_id, g.name
FROM
    invoice_line il
        LEFT JOIN
    track t ON t.track_id = il.track_id
        LEFT JOIN
    genre g ON g.genre_id = t.genre_id
GROUP BY il.invoice_id , g.name;

-- over an invoice diff. genres purchased

SELECT 
    il.invoice_id, al.title
FROM
    invoice_line il
        LEFT JOIN
    track t ON t.track_id = il.track_id
        LEFT JOIN
    album al ON al.album_id = t.album_id
GROUP BY il.invoice_id , al.title;

--  over an invoice diff. albums purchased

SELECT 
    il.invoice_id, a.name
FROM
    invoice_line il
        LEFT JOIN
    track t ON t.track_id = il.track_id
        LEFT JOIN
    album al ON al.album_id = t.album_id
        LEFT JOIN
    artist a ON a.artist_id = al.artist_id
GROUP BY il.invoice_id , a.name;

-- Different artists chosen in a single invoice.

-- 5.	Regional Market Analysis: Do customer purchasing behaviors and churn rates vary across different geographic regions or store locations? 
-- How might these correlate with local demographic or economic factors?

with first_six_months as
(
select billing_country, COUNT(customer_id) counter from invoice
where invoice_date between '2017-01-01' and '2017-06-30'
group by billing_country
),
last_six_months as
(
select billing_country, COUNT(customer_id) counter from invoice
where invoice_date between '2020-07-01' and '2020-12-31' 
group by billing_country
)
select f6.billing_country, (f6.counter - coalesce(l6.counter,0))/f6.counter * 100 churn_rate from first_six_months f6
left join  last_six_months l6 on f6.billing_country = l6.billing_country;

-- 6.	Customer Risk Profiling: Based on customer profiles (age, gender, location, purchase history), which customer segments are more likely to churn or pose a higher risk of reduced spending? What factors contribute to this risk?

select count(distinct customer_id) as Customer_count from invoice; -- count of all the customers
select count(distinct customer_id) as Customer_count_in_2020 from invoice where extract(year from invoice_date) = '2020'; -- 58 customers


-- 7.	Customer Lifetime Value Modeling: How can you leverage customer data (tenure, purchase history, engagement) to predict the lifetime value of different customer segments? This could inform targeted marketing and loyalty program strategies. Can you observe any common characteristics or purchase patterns among customers who have stopped purchasing?

with cte as(select inv.customer_id,inv.billing_country,inv.invoice_date, concat(c.first_name,' ',c.last_name) as customer_name,inv.total as invoice_total
from invoice inv
left join customer c on c.customer_id = inv.customer_id
group by customer_id,2,3,inv.total
order by customer_name),
cte2 as(
select customer_id, sum(total) as LTV
from invoice
group by customer_id)
select cte.customer_id, cte.billing_country, cte.invoice_date, cte.customer_name,cte.invoice_total, cte2.LTV
from cte left join cte2 on cte.customer_id = cte2.customer_id
order by cte2.LTV desc,cte.customer_name, cte.invoice_date;


-- 8.	If data on promotional campaigns (discounts, events, email marketing) is available, 
-- how could you measure their impact on customer acquisition, retention, and overall sales?

select count(*) from track; --  total available tracks 

SELECT 
    distinct t.name
FROM
    track t
WHERE
    t.track_id NOT IN (SELECT 
            il.track_id
        FROM
            invoice_line il
                LEFT JOIN
            invoice i ON i.invoice_id = il.invoice_id
        WHERE
            i.invoice_date >= '2020-07-01'
                AND i.invoice_date <= '2020-12-31');

-- Identifying songs that haven't been sold in the past 6 months, 
-- allowing promotion campaigns to be targeted at boosting their sales.

SELECT 
    CONCAT(c.first_name, ' ', c.last_name) AS full_name
FROM
    customer c
WHERE
    c.customer_id NOT IN (SELECT DISTINCT
            (customer_id)
        FROM
            invoice
        WHERE
            invoice_date >= '2020-07-01'
                AND invoice_date <= '2020-12-31');
-- finding cx that have not made any purchase in previous 6 months.



-- 9.	How would you approach this problem, if the objective and subjective questions were not given?
 
 
 select * from album;
SELECT DISTINCT
    *
FROM
    album; -- No duplicates

SELECT 
    *
FROM
    artist;
SELECT DISTINCT
    *
FROM
    artist; -- No duplicates

SELECT 
    *
FROM
    customer;
SELECT DISTINCT
    *
FROM
    customer; -- No duplicates
SELECT 
    COUNT(*)
FROM
    customer;
-- WHERE fax is NULL; ( count = 47)
-- WHERE state is NULL;(count = 29)
-- WHERE company is NULL; (count = 49)
-- 47 fax, 29 state and 49 company values are null in the customer table

SELECT 
    *
FROM
    employee; -- 1 reports_to value is null for employee_id = 1
SELECT DISTINCT
    *
FROM
    employee; -- No duplicates

SELECT 
    *
FROM
    genre;
SELECT DISTINCT
    *
FROM
    genre; -- No duplicates

SELECT 
    *
FROM
    invoice;
SELECT DISTINCT
    *
FROM
    invoice; -- No duplicates

SELECT 
    *
FROM
    invoice_line;
SELECT DISTINCT
    *
FROM
    invoice_line; -- No duplicates

SELECT 
    *
FROM
    media_type;
SELECT DISTINCT
    *
FROM
    media_type; -- No duplicates

SELECT 
    *
FROM
    playlist;
SELECT DISTINCT
    *
FROM
    playlist; -- No duplicates

SELECT 
    *
FROM
    playlist_track;
SELECT DISTINCT
    *
FROM
    playlist_track;

SELECT 
    *
FROM
    track;
SELECT DISTINCT
    *
FROM
    track; -- No duplicates


SELECT 
    SUM(total) AS yearly_revenue,
    EXTRACT(YEAR FROM invoice_date)
FROM
    invoice
GROUP BY EXTRACT(YEAR FROM invoice_date);

-- 1201.86	2017
-- 1147.41	2018
-- 1221.66	2019
-- 1138.50	2020

SELECT 
    customer_id, SUM(total) AS life_time_value
FROM
    invoice
GROUP BY customer_id
ORDER BY life_time_value DESC;

SELECT 
    billing_country, SUM(total) AS total_revenue
FROM
    invoice
GROUP BY billing_country
ORDER BY total_revenue DESC;



-- 10.	How can you alter the "Albums" table to add a new column named "ReleaseYear" of type INTEGER to store the release year of each album?

ALTER TABLE album
ADD COLUMN ReleaseYear int;
SELECT 
    *
FROM
    album;



-- 11.	Chinook is interested in understanding the purchasing behavior of customers based on their geographical location. 

-- They want to know the average total amount spent by customers from each country, along with the number of customers and the average number of tracks purchased per customer. Write an SQL query to provide this information.


with cte as(
select avg(total) Avg_total_amount_spent,
count(distinct customer_id) num_of_cust,
billing_country
from invoice i
left join invoice_line il on il.invoice_id = i.invoice_id
group by billing_country
),
cte2 as(
SELECT i.customer_id, sum(quantity) as quantity_purchased from invoice i
left join invoice_line il on il.invoice_id = i.invoice_id
group by i.customer_id
),
cte3 as(
select billing_country, avg(quantity_purchased) as avg_tracks_per_country
from invoice i
left join cte2 on cte2.customer_id = i.customer_id
group by billing_country
)
select * from cte
left join cte3 on cte3.billing_country = cte.billing_country;


/*
The average total amount spent per customer appears to fall between 8 and 12, with an outlier of 5.158 in Denmark. 
Additionally, most countries have a very small number of customers, typically in the single digits. 
The USA has the highest customer count.
*/